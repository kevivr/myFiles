To run the Jar file in the Res folder, Open command prompt and change directory to where the Res folder and the jar in it is in.
Then run the jar file using the command :

java -jar investment_mvc.jar

Then just follow the menu that opens in the console to use the application.